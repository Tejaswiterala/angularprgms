import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms'
import { AppComponent } from './app.component';
import { Route,RouterModule } from '@angular/router';
import { GamecityComponent } from './gamecity/gamecity.component';
import {HttpClientModule} from '@angular/common/http';
import { PlayComponent } from './play/play.component';
const routes:Route [] =[
  {
    path : 'gameform',
    component :GamecityComponent
  },
  {
    path : 'playform',
    component :PlayComponent

  }
  
]
@NgModule({
  declarations: [
    AppComponent,
    GamecityComponent,
    PlayComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    RouterModule.forRoot(routes),
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
