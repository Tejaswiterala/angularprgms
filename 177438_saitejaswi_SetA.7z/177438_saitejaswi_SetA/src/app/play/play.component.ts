import { Component, OnInit } from '@angular/core';
import { GameService } from '../game.service';
import {IGame} from '../IGame';
@Component({
  selector: 'app-play',
  templateUrl: './play.component.html',
  styleUrls: ['./play.component.css']
})
export class PlayComponent implements OnInit {
  balance: any;
  games:IGame[];
  availbal:number=600;
  servicecharge:number=100;
ispurchased:boolean;
  constructor(private service:GameService) { }

  ngOnInit() {
    this.service.getgame().subscribe(data=>this.games=data);
  }
  playnow(pr){
    let balance: number;
    let productprice:number;
    this.balance= this.availbal-this.servicecharge;
    productprice=pr.gameprice;
  if(this.balance>=productprice){
    this.balance=this.balance-productprice;
this.ispurchased=true;

  }
  
  }
}
  


