export interface IGame{
    gameid: number,
    gamename: string,
      
    gameprice: number
}