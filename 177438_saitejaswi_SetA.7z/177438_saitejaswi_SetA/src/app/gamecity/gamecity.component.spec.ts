import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GamecityComponent } from './gamecity.component';

describe('GamecityComponent', () => {
  let component: GamecityComponent;
  let fixture: ComponentFixture<GamecityComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GamecityComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GamecityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
