import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gamecity',
  templateUrl: './gamecity.component.html',
  styleUrls: ['./gamecity.component.css']
})
export class GamecityComponent implements OnInit {
  constructor() { }

  ngOnInit() {
    
  }
  onSubmit(data : any){
    console.log(data);

  }
  

}
