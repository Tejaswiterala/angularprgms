import { Injectable } from '@angular/core';
import { IGame } from './IGame';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class GameService {
  url : string ="/assets/gamelist.json";

  constructor(private http:HttpClient) { }
  getgame():Observable<IGame []>
  {
    return this.http.get<IGame []>(this.url);
  }
}

